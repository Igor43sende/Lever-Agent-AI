from app.services.session_manager import update_session
from app.services.scheduler_service import get_available_slots
from app.agents.scheduling_agent import schedule_appointment


def orchestrate(intent, user, message, session):

    state = session.get("state")

    if state == "waiting_date":

        slots = get_available_slots(message)

        update_session(user, "waiting_time", {"date": message})

        return f"Temos os seguintes horários disponíveis:\n{', '.join(slots)}"

    if state == "waiting_time":

        date = session["context"]["date"]

        return schedule_appointment(user, date, message)

    if intent == "schedule":

        update_session(user, "waiting_date")

        return "Para qual dia você deseja marcar a consulta?"

    return "Não entendi sua solicitação."