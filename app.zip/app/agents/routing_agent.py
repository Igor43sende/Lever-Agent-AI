from app.agents.scheduling_agent import schedule_appointment
from app.agents.cancel_agent import cancel_appointment
from app.agents.knowledge_agent import answer_question


def route_intent(intent, user, message, session):

    if intent == "schedule":
        return "Para qual dia você deseja marcar a consulta?"

    if intent == "cancel":
        return cancel_appointment(user)

    if intent == "question":
        return answer_question(message)

    return "Não entendi sua solicitação."