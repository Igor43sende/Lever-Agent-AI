from app.services.session_manager import update_session
from app.database.repository import create_appointment


def schedule_appointment(user, date, time):

    appointment = create_appointment(user, f"{date} {time}")

    update_session(user, "idle")

    return f"Consulta marcada para {date} às {time}"