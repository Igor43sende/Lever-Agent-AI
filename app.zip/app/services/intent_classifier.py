def classify_intent(message):

    message = message.lower()

    # agendamento
    if "marcar" in message or "agendar" in message or "consulta" in message:
        return "schedule"

    # cancelamento
    if "cancelar" in message or "cancelar consulta" in message:
        return "cancel"

    # perguntas
    if "horário" in message or "horario" in message:
        return "question"

    return "unknown"