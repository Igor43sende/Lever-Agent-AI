from app.services.intent_classifier import classify_intent
from app.agents.orchestrator_agent import orchestrate
from app.services.session_manager import get_session


def process_message(data):

    user = data.get("user")
    message = data.get("message")

    session = get_session(user)

    intent = classify_intent(message)

    response = orchestrate(intent, user, message, session)

    return response